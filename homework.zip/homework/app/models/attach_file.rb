class AttachFile < ActiveRecord::Base

end
