class Teacher < ActiveRecord::Base
end
