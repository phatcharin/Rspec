class Student < ActiveRecord::Base
end
