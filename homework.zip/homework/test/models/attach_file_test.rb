require 'test_helper'

class AttachFileTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
