require 'test_helper'

class PmTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
